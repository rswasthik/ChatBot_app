package ChatsModel;

public class ChatsModal {
    public int getSender;

    public ChatsModal(String message, String user_key) {
    }

    public String getMessage() {
    }
}
