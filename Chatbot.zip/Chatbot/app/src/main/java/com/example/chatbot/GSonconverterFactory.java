package com.example.chatbot;

public class GSonconverterFactory {
    public static void create() {
    }
}
