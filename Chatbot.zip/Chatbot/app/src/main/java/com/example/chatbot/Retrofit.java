package com.example.chatbot;

public class Retrofit {
    public RetrofitAPI create(Class<RetrofitAPI> retrofitAPIClass) {
        return null;
    }

    public static class Builder {
        public void baseUrl(String base_url) {
        }
    }
}
