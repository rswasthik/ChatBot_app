import junit.framework.TestCase;

public class ChatRVAdapterTest extends TestCase {

}